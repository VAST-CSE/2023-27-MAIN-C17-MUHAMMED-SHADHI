# Upload ClauseMind AI to GitHub

## Suggested repository details
- **Repository name:** `ClauseMind-AI` (confirm your college's prescribed naming format first)
- **Description:** AI-assisted contract review and Solidity smart-contract pattern screening prototype.
- **Visibility:** Follow your VAST-CSE coordinator's instructions. Use private if the project, dataset, or college policy requires it.

## Before uploading
1. Review every file for passwords, API keys, personal information, and confidential contracts.
2. Do not upload `.venv/`, downloaded model weights/cache, or the generated `clausemind.db` database. `.gitignore` excludes these.
3. Only upload sample contracts that your team is allowed to share publicly or with the organisation.
4. Confirm whether your college requires a specific README, licence, naming format, or team details.

## Upload through GitHub's website
1. Sign in to the GitHub account that has accepted the VAST-CSE invitation.
2. Open the repository created for your team under the `VAST-CSE` organisation.
3. Choose **Add file → Upload files**.
4. Upload the contents of this project folder (including `.gitignore` and this guide). Keep the folder structure for `samples/` and `tests/`.
5. Add a clear commit message such as `Add ClauseMind AI project prototype` and commit to the default branch.

## Upload using Git (optional)
Run these commands from this project folder after the repository has been created. Replace the URL with the actual repository URL shown by GitHub:

```powershell
git init
git add .
git status
git commit -m "Add ClauseMind AI project prototype"
git branch -M main
git remote add origin https://github.com/VAST-CSE/REPOSITORY-NAME.git
git push -u origin main
```

Check `git status` before committing. If Git reports that a confidential file is staged, remove it from staging before committing.

## Scope and limitations
This is a prototype, not a production legal service or comprehensive smart-contract auditor. Traditional-contract analysis combines rules with an optional general pretrained natural-language-inference model. Solidity findings are based on patterns and heuristics; the tool does not run a Solidity compiler, symbolic execution, fuzzing, or a dedicated audit engine. Review all findings manually.

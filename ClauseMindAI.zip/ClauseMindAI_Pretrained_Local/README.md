# ClauseMind AI — Local Pretrained Model Edition

This is a research/demo prototype for contract text review and Solidity code screening.

## Repository contents
- `app.py` — Flask application and analysis routes
- `samples/` — small demonstration inputs
- `tests/` — rule-based test suite
- `requirements.txt` — application dependencies
- `requirements-cpu.txt` — CPU-oriented dependency option
- `GITHUB_UPLOAD_GUIDE.md` — safe upload checklist and commands

## What is genuinely AI here?
Traditional-contract analysis can use the pretrained Hugging Face model `cross-encoder/nli-MiniLM2-L6-H768`, an 82.1M-parameter Natural Language Inference model trained on SNLI and MultiNLI. It is used for zero-shot candidate-label scoring against contract-risk categories. The model is **not trained specifically on legal contracts** and is not a legal expert. It complements explicit rule-based patterns; it does not replace them.

Model card: https://huggingface.co/cross-encoder/nli-MiniLM2-L6-H768

## Hardware / download
- Target: Windows 10/11, Python 3.10 or 3.11 recommended.
- 8 GB system RAM: use CPU inference or carefully try CUDA; keep other apps closed. GPU support depends on the installed PyTorch/CUDA build and driver.
- NVIDIA GPU with 4–8 GB VRAM: likely enough for this MiniLM model in inference, but GPU compatibility is not guaranteed until tested on your machine.
- Model weights are **not bundled in the ZIP**. On the first AI-enabled contract analysis, Transformers downloads model files from Hugging Face. Expect roughly hundreds of MB including tokenizer/config/dependencies; actual download size depends on selected files and cache. Internet is required for the first download. Later runs use the local Hugging Face cache.
- Solidity analysis is static regex/pattern heuristics, **not** Slither, Mythril, symbolic execution, fuzzing, or a full audit.
- The app does not send uploaded contract text to an external inference API. Model weights are fetched from Hugging Face; inference runs locally.

## Windows setup
Install Python 3.10/3.11 from python.org and tick **Add Python to PATH**.

```powershell
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python app.py
```

Then visit http://127.0.0.1:5000.

If PyTorch CUDA setup fails, CPU is the simplest fallback. For a CPU-only installation, use the official PyTorch selector for your OS/Python or try:

```powershell
python -m pip install --upgrade torch --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
```

Then confirm:
```powershell
python -c "import torch; print('torch',torch.__version__,'cuda',torch.cuda.is_available())"
```

## Test
In another terminal with the virtual environment active:
```powershell
python -m unittest discover -s tests -v
```
The tests validate deterministic rule-based logic and Solidity pattern signals without downloading the model. The model smoke test is optional and downloads weights.

## Demo sequence
1. Open the dashboard and click **Load sample**.
2. Click **Analyse contract** with the pretrained model checkbox enabled. First run may take a few minutes.
3. Inspect each finding's evidence and source. If model load fails, the API will state that and rule-based findings remain available.
4. Switch to Smart contract, load sample, and scan.
5. Explain honestly: pretrained general NLI model + transparent contract-specific rules; not a fine-tuned legal model.

## Important limitations
- Scores are heuristic review-priority indicators, not calibrated probabilities or legal conclusions.
- Zero-shot scores can be wrong or overconfident, especially on long, technical, or legal language. The model sees sentence-sized snippets and uses a general NLI training objective.
- Text extraction from PDF needs selectable text; scanned PDFs need OCR (not included).
- DOCX extraction currently reads paragraph text, not every table/header/footer.
- No Solidity compiler or static-analysis engine is bundled.

# Project State / Verification Notes

## Included
- Flask dashboard, contract and Solidity analysis endpoints
- SQLite analysis history
- Lazy loading of a real pretrained NLI model through Hugging Face Transformers
- Deterministic rule-based contract signals and Solidity pattern signals
- TXT/SOL/PDF/DOCX text extraction, file-size limit, sample documents and tests

## Verification in build environment
- Source is generated as a runnable prototype.
- The authoring environment did not install the full dependency stack or download model weights, so the Flask server, CUDA path, first-run model download and browser UI have **not** been end-to-end tested here.
- The included unit tests are written to exercise deterministic analysis functions, but must be run locally after installing requirements.
- Do not claim all tests passed unless they have actually been run.

## Architecture truth
- Pretrained model: cross-encoder/nli-MiniLM2-L6-H768 (general NLI, not legal-domain fine-tuned).
- Contract analysis: rule patterns + optional zero-shot NLI classification.
- Solidity analysis: regex heuristics only.
- No trained-from-scratch model, no custom fine-tuning, no Slither integration, no OCR.

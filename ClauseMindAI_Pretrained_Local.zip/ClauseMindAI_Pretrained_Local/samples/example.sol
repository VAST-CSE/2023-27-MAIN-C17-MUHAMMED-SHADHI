// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
contract ExampleVault {
    address public owner;
    mapping(address => uint256) public balances;
    constructor() { owner = msg.sender; }
    function withdraw(uint256 amount) external {
        require(balances[msg.sender] >= amount, "low balance");
        (bool ok,) = msg.sender.call{value: amount}("");
        require(ok, "transfer failed");
        balances[msg.sender] -= amount;
    }
    function forward(address target, bytes calldata data) external {
        (bool ok,) = target.delegatecall(data);
        require(ok, "delegatecall failed");
    }
    function ownerOnly() external view returns (bool) {
        return tx.origin == owner;
    }
}

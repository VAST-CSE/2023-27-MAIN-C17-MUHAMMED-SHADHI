import unittest
import app

class ContractRulesTests(unittest.TestCase):
    def test_liability_clause_detected(self):
        result = app.analyze_contract("The Provider shall not be liable for any indirect damages and total liability shall be limited to fees paid.", use_ai=False)
        ids = {f["id"] for f in result["findings"]}
        self.assertIn("liability_exclusion", ids)

    def test_balanced_nda_does_not_trigger_termination_or_liability(self):
        result = app.analyze_contract("Each party shall keep confidential information confidential. This Agreement is governed by the laws of England.", use_ai=False)
        ids = {f["id"] for f in result["findings"]}
        self.assertNotIn("one_sided_termination", ids)
        self.assertNotIn("liability_exclusion", ids)

    def test_unilateral_termination(self):
        result = app.analyze_contract("The Provider may terminate this Agreement at any time in its sole discretion without prior notice.", use_ai=False)
        self.assertIn("one_sided_termination", {f["id"] for f in result["findings"]})

    def test_auto_renewal(self):
        result = app.analyze_contract("This Agreement automatically renews for successive one-year terms unless either party gives notice.", use_ai=False)
        self.assertIn("auto_renewal", {f["id"] for f in result["findings"]})

class SolidityTests(unittest.TestCase):
    def test_low_level_call(self):
        result = app.analyze_solidity('contract X { function f() external { payable(msg.sender).call{value: 1}(""); } }')
        self.assertIn("low_level_call", {f["id"] for f in result["findings"]})

    def test_tx_origin(self):
        result = app.analyze_solidity("contract X { function f() external { require(tx.origin == owner); } }")
        self.assertIn("tx_origin", {f["id"] for f in result["findings"]})

    def test_access_control_prompt(self):
        result = app.analyze_solidity("contract X { function set(uint x) external { } }")
        self.assertIn("access_control_review", {f["id"] for f in result["findings"]})

if __name__ == "__main__":
    unittest.main()

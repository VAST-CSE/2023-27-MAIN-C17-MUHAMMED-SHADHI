from __future__ import annotations
import os, re, json, sqlite3, threading, time
from datetime import datetime
from pathlib import Path
from typing import Any

from flask import Flask, request, jsonify, render_template_string
from werkzeug.utils import secure_filename

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "clausemind.db"
MODEL_ID = os.getenv("CLAUSEMIND_MODEL", "cross-encoder/nli-MiniLM2-L6-H768")
MAX_UPLOAD_MB = int(os.getenv("CLAUSEMIND_MAX_UPLOAD_MB", "8"))
ALLOWED_EXTENSIONS = {".txt", ".sol", ".pdf", ".docx"}
MODEL_LOCK = threading.Lock()
_NLI_PIPELINE = None
_MODEL_ERROR = None
_MODEL_DEVICE = "not loaded"

# These are screening prompts, not a legal ontology or calibrated risk model.
RISK_LABELS = {
    "liability_exclusion": ("Potentially broad exclusion or cap of liability", "A clause broadly excludes or caps a party's liability, including for negligence, indirect loss, or all damages.", "high"),
    "one_sided_termination": ("One-sided termination right", "A clause gives only one party a broad right to terminate, without a comparable right for the other party.", "medium"),
    "indemnity": ("Indemnity obligation", "A clause requires a party to indemnify, defend, or hold another party harmless against claims, losses, or expenses.", "medium"),
    "auto_renewal": ("Automatic renewal", "A clause automatically renews or extends the contract unless notice is given before a deadline.", "medium"),
    "unilateral_change": ("Unilateral variation", "A clause allows one party to change terms, prices, services, or policies without the other party's agreement.", "high"),
    "late_payment": ("Late-payment consequences", "A clause imposes interest, fees, penalties, or other consequences for late payment.", "low"),
    "confidentiality": ("Confidentiality duty", "A clause imposes confidentiality or non-disclosure obligations on one or both parties.", "low"),
    "personal_data": ("Personal-data handling", "A clause addresses personal information, privacy, data processing, or security obligations.", "medium"),
    "ip_ownership": ("Intellectual-property allocation", "A clause allocates ownership or licensing rights in intellectual property, deliverables, code, or work product.", "medium"),
    "dispute_resolution": ("Dispute resolution", "A clause sets the forum or process for disputes, such as courts, arbitration, or mediation.", "low"),
    "governing_law": ("Governing law", "A clause specifies the law or jurisdiction governing the contract.", "low"),
    "non_compete": ("Restriction on competition or solicitation", "A clause restricts competition, solicitation, or working with customers or employees after or during the agreement.", "medium"),
    "payment_terms": ("Payment obligation", "A clause specifies payment amounts, invoices, due dates, or payment conditions.", "low"),
    "limitation_of_remedies": ("Limited remedies", "A clause limits the remedies available to a party or makes a remedy exclusive.", "medium"),
}
RULES = [
    ("liability_exclusion", re.compile(r"\b(exclude|excludes|excluded|excluding|no liability|not liable|shall not be liable|liability shall be limited|cap(?:ped)? at)\b", re.I)),
    ("one_sided_termination", re.compile(r"\b(terminate|termination|end this agreement)\b", re.I)),
    ("indemnity", re.compile(r"\b(indemnif(?:y|ies|ication)|hold harmless|defend and indemnify)\b", re.I)),
    ("auto_renewal", re.compile(r"\b(automatically renew|auto(?:matic)? renewal|renewal term|unless (?:either|the) party gives notice)\b", re.I)),
    ("unilateral_change", re.compile(r"\b(sole discretion|may change|right to modify|modify these terms|change the fees|without prior consent)\b", re.I)),
    ("late_payment", re.compile(r"\b(late fee|late payment|interest of \d|overdue amount|past due)\b", re.I)),
    ("confidentiality", re.compile(r"\b(confidential|non-disclosure|nondisclosure)\b", re.I)),
    ("personal_data", re.compile(r"\b(personal data|personal information|data processing|privacy|security incident)\b", re.I)),
    ("ip_ownership", re.compile(r"\b(intellectual property|work product|source code|ownership of (?:the )?(?:work|deliverables|materials))\b", re.I)),
    ("dispute_resolution", re.compile(r"\b(arbitration|mediation|dispute resolution|courts? of)\b", re.I)),
    ("governing_law", re.compile(r"\b(governed by the laws of|governing law|laws of the state of)\b", re.I)),
    ("non_compete", re.compile(r"\b(non-compete|non compete|non-solicit|not solicit|competing business)\b", re.I)),
    ("payment_terms", re.compile(r"\b(payment shall be|within \d+ days|invoice|pay(?:ment)? of \$|fees shall be)\b", re.I)),
    ("limitation_of_remedies", re.compile(r"\b(exclusive remedy|sole remedy|limited remedies|remedies are limited)\b", re.I)),
]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
            kind TEXT NOT NULL, filename TEXT NOT NULL, score INTEGER NOT NULL,
            summary TEXT NOT NULL, findings_json TEXT NOT NULL
        )""")

def get_nli_pipeline():
    """Load the real pretrained NLI model only when requested; cache it for later runs."""
    global _NLI_PIPELINE, _MODEL_ERROR, _MODEL_DEVICE
    if _NLI_PIPELINE is not None:
        return _NLI_PIPELINE
    if _MODEL_ERROR:
        return None
    with MODEL_LOCK:
        if _NLI_PIPELINE is not None:
            return _NLI_PIPELINE
        try:
            import torch
            from transformers import pipeline
            device = 0 if torch.cuda.is_available() else -1
            _NLI_PIPELINE = pipeline(
                "zero-shot-classification",
                model=MODEL_ID,
                device=device,
                model_kwargs={"low_cpu_mem_usage": True}
            )
            _MODEL_DEVICE = f"CUDA GPU ({torch.cuda.get_device_name(0)})" if device == 0 else "CPU"
            return _NLI_PIPELINE
        except Exception as exc:
            _MODEL_ERROR = f"{type(exc).__name__}: {exc}"
            return None

def model_status():
    loaded = _NLI_PIPELINE is not None
    return {
        "model_id": MODEL_ID,
        "loaded": loaded,
        "available": loaded or _MODEL_ERROR is None,
        "device": _MODEL_DEVICE,
        "error": _MODEL_ERROR,
        "note": "Model is downloaded on first AI analysis and cached locally by Hugging Face."
    }

def split_sentences(text: str) -> list[str]:
    # Keep meaningful sentence-sized chunks while avoiding a single huge NLI input.
    chunks = re.split(r"(?<=[.!?;])\s+|\n+", text)
    return [re.sub(r"\s+", " ", c).strip() for c in chunks if len(c.strip()) >= 18]

def rule_findings(text: str) -> list[dict[str, Any]]:
    sentences = split_sentences(text)
    found = []
    for key, pattern in RULES:
        hits = []
        for s in sentences:
            if pattern.search(s):
                # Reduce common false positives by requiring a relevant cue for generic termination.
                if key == "one_sided_termination":
                    if not re.search(r"\b(sole discretion|without cause|only (?:the )?(?:company|supplier|customer|provider)|may terminate|right to terminate|terminate at any time)\b", s, re.I):
                        continue
                if key == "liability_exclusion" and re.search(r"\b(no liability insurance|certificate of liability)\b", s, re.I):
                    continue
                hits.append(s)
        if hits:
            title, desc, severity = RISK_LABELS[key]
            found.append({
                "id": key, "title": title, "severity": severity,
                "explanation": desc, "evidence": hits[:3],
                "source": "Rule-based signal", "confidence": None
            })
    return found

def semantic_findings(text: str, max_sentences: int = 18) -> list[dict[str, Any]]:
    pipe = get_nli_pipeline()
    if pipe is None:
        return []
    sentences = split_sentences(text)[:max_sentences]
    if not sentences:
        return []
    # Use a small candidate set for each sentence; this is semantic classification, not legal advice.
    labels = [v[0] for v in RISK_LABELS.values()]
    try:
        outputs = pipe(sentences, candidate_labels=labels, multi_label=True, hypothesis_template="This contract sentence is about {}.")
    except Exception:
        # Compatibility fallback for pipeline implementations expecting one input at a time.
        outputs = [pipe(s, candidate_labels=labels, multi_label=True, hypothesis_template="This contract sentence is about {}.") for s in sentences]
    if isinstance(outputs, dict):
        outputs = [outputs]
    best_by_label = {}
    for sentence, output in zip(sentences, outputs):
        for label, score in zip(output.get("labels", []), output.get("scores", [])):
            score = float(score)
            if score < 0.52:
                continue
            match = next((k for k, v in RISK_LABELS.items() if v[0] == label), None)
            if not match:
                continue
            if match not in best_by_label or score > best_by_label[match]["confidence"]:
                title, desc, severity = RISK_LABELS[match]
                best_by_label[match] = {
                    "id": match, "title": title, "severity": severity,
                    "explanation": desc, "evidence": [sentence],
                    "source": "Pretrained NLI model", "confidence": round(score, 3)
                }
    return list(best_by_label.values())

def analyze_contract(text: str, use_ai: bool = True) -> dict[str, Any]:
    rules = rule_findings(text)
    ai_findings = semantic_findings(text) if use_ai else []
    combined = {f["id"]: f for f in rules}
    for f in ai_findings:
        if f["id"] in combined:
            # Preserve concrete rule evidence; annotate that the model corroborated it.
            combined[f["id"]]["source"] = "Rule + pretrained NLI model"
            combined[f["id"]]["confidence"] = f["confidence"]
            for ev in f["evidence"]:
                if ev not in combined[f["id"]]["evidence"] and len(combined[f["id"]]["evidence"]) < 3:
                    combined[f["id"]]["evidence"].append(ev)
        else:
            combined[f["id"]] = f
    findings = sorted(combined.values(), key=lambda x: ({"high": 0, "medium": 1, "low": 2}.get(x["severity"], 3), -(x["confidence"] or 0)))
    # Checklist is explicitly a prompt to review, not a claim that the provision is absent.
    lower = text.lower()
    checklist = []
    for key, label in [
        ("termination", "Check whether termination rights are balanced and notice periods are clear."),
        ("governing law", "Confirm the governing-law clause is appropriate for the parties."),
        ("confidential", "Confirm confidentiality duties, exceptions and duration are clear."),
        ("dispute", "Check whether dispute resolution and venue are specified."),
        ("data", "Check whether data protection and security obligations fit the data involved."),
    ]:
        if key not in lower:
            checklist.append(label)
    score = min(100, sum({"high": 24, "medium": 13, "low": 5}.get(f["severity"], 5) for f in findings))
    if score >= 55: overall = "High review priority"
    elif score >= 25: overall = "Moderate review priority"
    else: overall = "Lower review priority"
    return {"score": score, "overall": overall, "findings": findings, "checklist": checklist,
            "engine": "Hybrid rules + pretrained NLI" if use_ai and _NLI_PIPELINE else ("Rule-based fallback" if not ai_findings else "Hybrid rules + pretrained NLI"),
            "model": model_status()}

SOLIDITY_PATTERNS = [
    ("low_level_call", r"\.call\s*\{[^}]*value\s*:", "high", "Low-level ETH call", "Low-level value transfer can require checks-effects-interactions and explicit return-value handling."),
    ("delegatecall", r"\.delegatecall\s*\(", "high", "delegatecall usage", "delegatecall executes code in the caller's storage context; verify target trust and storage layout."),
    ("tx_origin", r"\btx\.origin\b", "high", "tx.origin authentication", "Using tx.origin for authorisation can enable phishing-style call-chain attacks."),
    ("unchecked", r"\bunchecked\s*\{", "medium", "Unchecked arithmetic block", "Arithmetic overflow/underflow checks are disabled in this block; verify bounds."),
    ("timestamp", r"\bblock\.timestamp\b", "low", "Block timestamp dependency", "Block timestamps have limited miner/validator influence and should not be used as precise randomness."),
    ("selfdestruct", r"\bselfdestruct\s*\(", "medium", "selfdestruct usage", "Review intended lifecycle semantics and compiler/EVM-version behaviour."),
    ("external_call", r"\.call\s*\(", "medium", "Low-level external call", "Check call success, reentrancy protection, and state-update ordering."),
]
def analyze_solidity(code: str) -> dict[str, Any]:
    findings = []
    for key, pattern, severity, title, explanation in SOLIDITY_PATTERNS:
        for m in re.finditer(pattern, code, re.I):
            line = code.count("\n", 0, m.start()) + 1
            excerpt = code.splitlines()[line-1].strip() if line <= len(code.splitlines()) else ""
            findings.append({"id": key, "title": title, "severity": severity, "explanation": explanation,
                             "evidence": [f"Line {line}: {excerpt[:240]}"], "source": "Static pattern heuristic", "confidence": None})
            break
    if re.search(r"\bfunction\b", code) and not re.search(r"\b(onlyOwner|onlyRole|hasRole|AccessControl|Ownable)\b", code):
        findings.append({"id": "access_control_review", "title": "Review access control", "severity": "medium",
                         "explanation": "No common access-control marker was detected. This is not proof that access control is missing; inspect modifiers, inheritance and call paths.",
                         "evidence": ["One or more functions detected, but no common access-control marker found."],
                         "source": "Static review prompt", "confidence": None})
    score = min(100, sum({"high": 25, "medium": 14, "low": 6}.get(f["severity"], 5) for f in findings))
    return {"score": score, "overall": "High review priority" if score >= 50 else "Moderate review priority" if score >= 20 else "Lower review priority",
            "findings": findings, "engine": "Solidity static heuristics", "model": model_status(),
            "warning": "This is not a substitute for Slither, compiler analysis, fuzzing, or a professional security audit."}

def extract_text(filename: str, raw: bytes) -> str:
    ext = Path(filename).suffix.lower()
    if ext in {".txt", ".sol"}:
        return raw.decode("utf-8", errors="replace")
    if ext == ".pdf":
        from pypdf import PdfReader
        import io
        reader = PdfReader(io.BytesIO(raw))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if ext == ".docx":
        from docx import Document
        import io
        doc = Document(io.BytesIO(raw))
        return "\n".join(p.text for p in doc.paragraphs)
    raise ValueError("Supported files: TXT, SOL, PDF, DOCX.")

def save_analysis(kind, filename, result):
    summary = f'{result.get("overall", "")} · {len(result.get("findings", []))} findings'
    with db() as conn:
        cur = conn.execute("INSERT INTO analyses(created_at,kind,filename,score,summary,findings_json) VALUES(?,?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), kind, filename, result["score"], summary, json.dumps(result)))
        return cur.lastrowid

HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ClauseMind AI</title><style>
:root{--bg:#0b1020;--panel:#121a2d;--line:#26344e;--text:#eef3ff;--muted:#9baac4;--cyan:#5ce1e6;--purple:#a99bff;--red:#ff7474;--amber:#ffd27a;--green:#82e6b1}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 10% 0%,#182748 0,transparent 42%),var(--bg);color:var(--text);font:15px/1.5 Inter,Segoe UI,Arial,sans-serif}.wrap{max-width:1180px;margin:auto;padding:26px 20px 60px}.top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:24px}.brand{display:flex;align-items:center;gap:12px}.logo{width:44px;height:44px;border-radius:14px;background:linear-gradient(135deg,var(--cyan),var(--purple));color:#071120;display:grid;place-items:center;font-weight:900;font-size:21px}.muted{color:var(--muted)}h1{font-size:24px;margin:0}h2{font-size:18px;margin:0 0 12px}.tag{font-size:12px;border:1px solid var(--line);padding:7px 10px;border-radius:99px;color:var(--muted)}.grid{display:grid;grid-template-columns:1.1fr .9fr;gap:18px}.panel{background:rgba(18,26,45,.93);border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 14px 38px #0002}.tabs{display:flex;gap:8px;margin-bottom:14px}.tab,button{border:1px solid var(--line);background:#1a2540;color:var(--text);padding:10px 14px;border-radius:10px;cursor:pointer;font-weight:650}.tab.active,button.primary{background:linear-gradient(120deg,#5ce1e6,#a99bff);color:#091020;border:0}.tabpane{display:none}.tabpane.active{display:block}textarea{width:100%;min-height:230px;background:#0a1120;color:var(--text);border:1px solid var(--line);border-radius:12px;padding:13px;font:13px/1.6 ui-monospace,Consolas,monospace;resize:vertical}input[type=file]{max-width:100%;color:var(--muted)}.row{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin:13px 0}.checks{display:flex;gap:9px;align-items:center;color:var(--muted);font-size:13px}.btnrow{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}button:disabled{opacity:.5;cursor:wait}.status{font-size:13px;color:var(--muted);margin-top:12px}.statgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.stat{background:#0b1222;border:1px solid var(--line);border-radius:12px;padding:13px}.stat strong{font-size:23px;display:block}.stat span{font-size:12px;color:var(--muted)}.model{margin-top:13px;padding:12px;border-radius:12px;background:#0b1222;border:1px solid var(--line);font-size:13px}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--amber);margin-right:6px}.dot.ok{background:var(--green)}.result{margin-top:18px}.resulthead{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.score{font-size:29px;font-weight:800}.finding{border:1px solid var(--line);background:#0b1222;border-radius:12px;padding:13px;margin-top:10px}.findingtop{display:flex;gap:10px;align-items:center;justify-content:space-between}.sev{font-size:10px;text-transform:uppercase;letter-spacing:.07em;padding:4px 7px;border-radius:6px}.high{background:#4a2029;color:#ff9a9a}.medium{background:#4b3a1b;color:#ffdc91}.low{background:#183e36;color:#92edc3}.finding p{margin:8px 0;color:#c3cfe3;font-size:13px}.evidence{font:12px/1.5 ui-monospace,Consolas,monospace;color:#a6b8d6;background:#111c31;padding:9px;border-radius:8px;white-space:pre-wrap;overflow-wrap:anywhere}.history{display:grid;gap:8px;margin-top:12px}.hist{display:flex;justify-content:space-between;gap:12px;padding:10px;border:1px solid var(--line);border-radius:10px;font-size:13px}.small{font-size:12px;color:var(--muted)}.warning{border-left:3px solid var(--amber);padding:10px 12px;color:#d6dff0;background:#191d2b;border-radius:0 8px 8px 0;font-size:12px;margin-top:12px}.hidden{display:none!important}@media(max-width:820px){.grid{grid-template-columns:1fr}.top{align-items:flex-start}.statgrid{grid-template-columns:repeat(3,1fr)}}@media(max-width:450px){.wrap{padding:16px 12px}.panel{padding:14px}.statgrid{grid-template-columns:1fr 1fr}}
</style></head><body><div class="wrap">
<header class="top"><div class="brand"><div class="logo">C</div><div><h1>ClauseMind AI</h1><div class="muted">Contract intelligence · local-first prototype</div></div></div><div class="tag">PHASE 1 · RESEARCH DEMO</div></header>
<div class="grid"><section class="panel"><h2>Analyse a document</h2><div class="tabs"><button class="tab active" data-tab="contract">Traditional contract</button><button class="tab" data-tab="solidity">Smart contract</button></div>
<div id="contract" class="tabpane active"><div class="row"><span class="small">Paste contract text or upload a file</span><input id="contractFile" type="file" accept=".txt,.pdf,.docx"></div><textarea id="contractText" placeholder="Paste agreement clauses here..."></textarea><div class="row"><label class="checks"><input type="checkbox" id="useAI" checked> Use pretrained NLI model (first run downloads weights)</label></div><div class="btnrow"><button class="primary" id="analyzeContract">Analyse contract</button><button id="sampleContract">Load sample</button></div></div>
<div id="solidity" class="tabpane"><div class="row"><span class="small">Paste Solidity source or upload .sol</span><input id="solFile" type="file" accept=".sol,.txt"></div><textarea id="solText" placeholder="pragma solidity ^0.8.20; ..."></textarea><div class="btnrow"><button class="primary" id="analyzeSol">Scan Solidity</button><button id="sampleSol">Load sample</button></div></div>
<div class="status" id="status">Ready. The pretrained model is loaded only when AI analysis is requested.</div></section>
<aside class="panel"><h2>Engine status</h2><div class="statgrid"><div class="stat"><strong id="statAnalyses">—</strong><span>Analyses saved</span></div><div class="stat"><strong id="statFindings">—</strong><span>Last findings</span></div><div class="stat"><strong id="statScore">—</strong><span>Last score</span></div></div><div class="model"><div><span class="dot" id="modelDot"></span><b id="modelState">Model not loaded</b></div><div class="small" id="modelDetail" style="margin-top:6px">cross-encoder/nli-MiniLM2-L6-H768</div><div class="small" id="deviceDetail" style="margin-top:4px">Weights are downloaded from Hugging Face on first AI analysis.</div></div><h2 style="margin-top:20px">Recent analyses</h2><div id="history" class="history"><div class="small">No analyses yet.</div></div><div class="warning">Risk scores are heuristic review-priority indicators, not probabilities or legal advice. Solidity checks are not a full security audit.</div></aside></div>
<section class="panel result hidden" id="result"><div class="resulthead"><div><div class="small" id="resultKind">ANALYSIS</div><h2 id="resultTitle">Results</h2></div><div class="score" id="resultScore">0/100</div></div><p class="muted" id="resultEngine"></p><div id="findings"></div><div id="checklistWrap"><h2 style="margin-top:18px">Checklist prompts</h2><ul id="checklist"></ul></div><div id="resultWarning" class="warning hidden"></div></section>
<footer class="small" style="margin-top:18px">Prototype for educational evaluation. Review source evidence; do not rely on automated output as a legal conclusion.</footer></div>
<script>
const $=id=>document.getElementById(id);
let currentTab='contract';
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tabpane').forEach(x=>x.classList.remove('active'));b.classList.add('active');currentTab=b.dataset.tab;$(currentTab).classList.add('active')}));
const contractSample=`VENDOR SERVICES AGREEMENT
The Customer shall pay invoices within 30 days. Late payments incur interest at 2% per month.
The Provider may terminate this Agreement at any time in its sole discretion without prior notice.
The Provider shall not be liable for any indirect, incidental or consequential damages, and total liability shall be limited to fees paid in the previous month.
This Agreement automatically renews for successive one-year terms unless either party gives 60 days' written notice.
The parties shall keep all Confidential Information confidential. This Agreement is governed by the laws of England and Wales.`;
const solSample=`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
contract Vault {
    mapping(address => uint256) public balances;
    function withdraw(uint256 amount) external {
        require(balances[msg.sender] >= amount, "low balance");
        (bool ok,) = msg.sender.call{value: amount}("");
        require(ok, "transfer failed");
        balances[msg.sender] -= amount;
    }
    function forward(address target, bytes calldata data) external {
        (bool ok,) = target.delegatecall(data);
        require(ok, "delegatecall failed");
    }
}`;
$('sampleContract').onclick=()=>{$('contractText').value=contractSample};
$('sampleSol').onclick=()=>{$('solText').value=solSample};
$('contractFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>8*1024*1024){setStatus('File too large (8 MB limit).');return;} if(f.name.toLowerCase().endsWith('.txt')){$('contractText').value=await f.text();}else{setStatus('Upload will be processed on analysis.');}};
$('solFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>8*1024*1024){setStatus('File too large (8 MB limit).');return;} if(f.name.toLowerCase().endsWith('.sol')||f.name.toLowerCase().endsWith('.txt'))$('solText').value=await f.text();};
function setStatus(s){$('status').textContent=s}
async function postAnalysis(kind){const isSol=kind==='solidity';const input=isSol?$('solText').value:$('contractText').value;const file=(isSol?$('solFile'):$('contractFile')).files[0];if(!input.trim()&&!file){setStatus('Paste text or select a supported file first.');return;}const btn=$(isSol?'analyzeSol':'analyzeContract');btn.disabled=true;setStatus(isSol?'Scanning source…':'Analysing. The first AI run may take a few minutes while model weights download…');try{let res;if(file && !input.trim()){const fd=new FormData();fd.append('file',file);fd.append('use_ai',String($('useAI').checked));res=await fetch('/api/analyse/'+kind,{method:'POST',body:fd})}else{res=await fetch('/api/analyse/'+kind,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:input,filename:file?.name||'pasted-text',use_ai:$('useAI').checked})})}const data=await res.json();if(!res.ok)throw new Error(data.error||'Analysis failed');renderResult(data);await refresh();setStatus('Analysis complete. Check evidence snippets and engine source labels.')}catch(e){setStatus('Error: '+e.message)}finally{btn.disabled=false}}
$('analyzeContract').onclick=()=>postAnalysis('contract');$('analyzeSol').onclick=()=>postAnalysis('solidity');
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderResult(d){$('result').classList.remove('hidden');$('resultKind').textContent=(d.kind||'analysis').toUpperCase();$('resultTitle').textContent=d.overall||'Results';$('resultScore').textContent=(d.score??0)+'/100';$('resultEngine').textContent='Engine: '+(d.engine||'unknown')+' · '+(d.findings?.length||0)+' findings';$('findings').innerHTML=(d.findings||[]).map(f=>`<article class="finding"><div class="findingtop"><b>${esc(f.title)}</b><span class="sev ${esc(f.severity)}">${esc(f.severity)}</span></div><p>${esc(f.explanation)}</p>${f.confidence!=null?`<div class="small">Model score: ${(f.confidence*100).toFixed(1)}% · not a calibrated risk probability</div>`:''}<div class="small" style="margin:7px 0">${esc(f.source)}</div>${(f.evidence||[]).map(e=>`<div class="evidence">${esc(e)}</div>`).join('')}</article>`).join('')||'<p class="muted">No signals detected. This does not prove the contract or code is safe.</p>';$('checklistWrap').classList.toggle('hidden',!(d.checklist||[]).length);$('checklist').innerHTML=(d.checklist||[]).map(x=>`<li>${esc(x)}</li>`).join('');$('resultWarning').classList.toggle('hidden',!d.warning);$('resultWarning').textContent=d.warning||'';window.scrollTo({top:$('result').offsetTop-20,behavior:'smooth'})}
async function refresh(){try{const r=await fetch('/api/status');const d=await r.json();$('modelState').textContent=d.model.loaded?'Pretrained model loaded':d.model.error?'Model failed to load':'Model not loaded yet';$('modelDot').classList.toggle('ok',d.model.loaded);$('modelDetail').textContent=d.model.model_id;$('deviceDetail').textContent=d.model.loaded?'Running on '+d.model.device:d.model.error?d.model.error:d.model.note;$('statAnalyses').textContent=d.stats.analyses;$('statFindings').textContent=d.stats.findings;$('statScore').textContent=d.stats.score==null?'—':d.stats.score+'/100';$('history').innerHTML=d.history.length?d.history.map(h=>`<div class="hist"><div><b>${esc(h.filename)}</b><div class="small">${esc(h.kind)} · ${esc(h.created_at)}</div></div><div style="text-align:right"><b>${h.score}/100</b><div class="small">${h.findings} findings</div></div></div>`).join(''):'<div class="small">No analyses yet.</div>'}catch(e){}}
refresh();
</script></body></html>"""

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

@app.get("/")
def index():
    return render_template_string(HTML)

@app.get("/api/status")
def status():
    with db() as conn:
        rows = conn.execute("SELECT * FROM analyses ORDER BY id DESC LIMIT 6").fetchall()
        total = conn.execute("SELECT COUNT(*) AS n FROM analyses").fetchone()["n"]
        last = rows[0] if rows else None
    history = []
    for row in rows:
        result = json.loads(row["findings_json"])
        history.append({"id": row["id"], "kind": row["kind"], "filename": row["filename"],
                        "created_at": row["created_at"].replace("T", " "), "score": row["score"],
                        "findings": len(result.get("findings", []))})
    return jsonify({"model": model_status(), "stats": {"analyses": total,
        "findings": len(json.loads(last["findings_json"]).get("findings", [])) if last else 0,
        "score": last["score"] if last else None}, "history": history})

def read_request_text(kind):
    if request.files.get("file"):
        f = request.files["file"]
        filename = secure_filename(f.filename or "upload")
        if Path(filename).suffix.lower() not in ALLOWED_EXTENSIONS:
            raise ValueError("Unsupported file type. Use TXT, SOL, PDF, or DOCX.")
        raw = f.read()
        if not raw:
            raise ValueError("The uploaded file is empty.")
        return filename, extract_text(filename, raw), request.form.get("use_ai", "true").lower() == "true"
    payload = request.get_json(silent=True) or {}
    text = str(payload.get("text", "")).strip()
    if not text:
        raise ValueError("Paste some text or upload a file.")
    if len(text) > 500_000:
        raise ValueError("Text is too long (500,000 character limit).")
    return secure_filename(str(payload.get("filename", "pasted-text"))[:120]) or "pasted-text", text, bool(payload.get("use_ai", True))

@app.post("/api/analyse/contract")
def contract_endpoint():
    try:
        filename, text, use_ai = read_request_text("contract")
        result = analyze_contract(text, use_ai=use_ai)
        result["kind"] = "contract"
        if use_ai and not result["model"]["loaded"]:
            result["notice"] = "Pretrained model could not be loaded; results contain rule-based findings only."
        result["analysis_id"] = save_analysis("contract", filename, result)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 400

@app.post("/api/analyse/solidity")
def solidity_endpoint():
    try:
        filename, text, _ = read_request_text("solidity")
        result = analyze_solidity(text)
        result["kind"] = "solidity"
        result["analysis_id"] = save_analysis("solidity", filename, result)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 400

@app.get("/api/history/<int:analysis_id>")
def history_detail(analysis_id):
    with db() as conn:
        row = conn.execute("SELECT * FROM analyses WHERE id=?", (analysis_id,)).fetchone()
    if not row:
        return jsonify({"error": "Analysis not found"}), 404
    return jsonify(json.loads(row["findings_json"]))

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": f"Upload exceeds {MAX_UPLOAD_MB} MB limit."}), 413

if __name__ == "__main__":
    init_db()
    print(f"ClauseMind AI starting. Model: {MODEL_ID}")
    print("The pretrained model downloads on the first AI analysis; first startup can take several minutes.")
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
